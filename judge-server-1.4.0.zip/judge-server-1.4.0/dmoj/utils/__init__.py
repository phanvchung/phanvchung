import os

setbufsize_path = os.path.join(os.path.dirname(__file__), 'setbufsize.so')
del os
